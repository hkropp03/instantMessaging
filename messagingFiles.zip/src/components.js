export default function NewMessage(){
    return(
        <button>Please your users you would like to message</button>
    )
}